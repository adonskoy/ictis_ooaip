﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections;
using System.Text;
using System.Threading.Tasks;



namespace Figures
{
    //Структура, описывающая точку на плоскости
    class Point
    {
        public double x, y;

        public Point(double a, double b)
        {
            x = a;
            y = b;
        }

        public Point()
        {

        }
    }

    //Структура, описывающая линию на плоскости
    class Line
    {

        const double EPS = 1e-9;
        public Figures.Point p1, p2;
        public double a, b, c;

        public Line(Point aa, Point bb)
        {
            p1 = aa;
            p2 = bb;
            a = p2.y - p1.y;
            b = -(p2.x - p1.x);
            c = -p1.x * (p2.y - p1.y) + p1.y * (p2.x - p1.x);
        }

        //Проверка того, что точка на линии
        public bool onLine(Point c)
        {
            return (Math.Min(p1.x, p2.x) <= c.x + EPS && c.x <= Math.Max(p1.x, p2.x) + EPS) &&
                   (Math.Min(p1.y, p2.y) <= c.y + EPS && c.y <= Math.Max(p1.y, p2.y) + EPS);
        }

        //Длинна линии
        public double getLenght()
        {
            return Math.Sqrt(Math.Pow(p2.x - p1.x, 2) + Math.Pow(p2.y - p1.y, 2));
        }

        public double det(double a, double b, double c, double d)
        {
            return a * d - b * c;
        }

        //Точка пересечения 2 линий
        public Point cross(Line n)
        {
            Point res = new Point();
            double zn = det(a, b, n.a, n.b);
            if (Math.Abs(zn) < EPS)
                return null;
            res.x = -det(c, b, n.c, n.b) / zn;
            res.y = -det(a, c, n.a, n.c) / zn;
            if (onLine(res) && n.onLine(res))
            {
                return res;
            }
            else
            {
                return null;
            }
        }

        //Середина линии
        public Point getCenter()
        {
            Point res = new Point();
            res.x = (p1.x + p2.x) / 2;
            res.y = (p1.y + p2.y) / 2;
            return res;
        }

        //Проверка параллельности двух линий
        public bool isParallel(Line n)
        {
            return Math.Abs(det(a, b, n.a, n.b)) < EPS;
        }

        //Проверка эквивалентности двух линий
        public bool isEquivalent(Line n)
        {
            return Math.Abs(det(a, b, n.a, n.b)) < EPS
          && Math.Abs(det(a, c, n.a, n.c)) < EPS
          && Math.Abs(det(b, c, n.b, n.c)) < EPS;
        }
    }

    //Абстрактный класс фигуры
    abstract class Figure
    {

        //Функция вычисления площади фигуры
        public abstract double getSquare();

        //Функция вычисления центра масс фигуры
        public abstract Point getCenterOfMass();

        //Функция вычисления периметра фигуры
        public abstract double getPerimeter();

        //Функция возвращающая тип фигуры
        public abstract String getType();

    }

    //Класс прямоугольника
    class Rectangle : Figure
    {

        Point p1, p2, p3, p4;

        override public double getSquare()
        {
            return (new Line(p1, p2).getLenght()) * (new Line(p2, p3).getLenght());
        }

        override public Point getCenterOfMass()
        {
            Line d1 = new Line(p1, p3);
            Line d2 = new Line(p2, p4);
            return d1.cross(d2);
        }

        override public double getPerimeter()
        {
            return ((new Line(p1, p2).getLenght()) + (new Line(p2, p3).getLenght())) * 2;
        }

        override public String getType()
        {
            return "Rectangle";
        }

        public Rectangle(Point a, Point b, Point c, Point d)
        {
            Line ab = new Line(a, b);
            Line bc = new Line(b, c);
            Line cd = new Line(c, d);
            Line da = new Line(d, a);
            if ((ab.isParallel(cd) && !ab.isEquivalent(cd)) && (bc.isParallel(da) && !bc.isEquivalent(da)))
            {
                p1 = a;
                p2 = b;
                p3 = c;
                p4 = d;
            }
            else
            {
                throw (new System.Exception("It's not a rectangle"));
            }
        }
    }

    //Класс треугольника
    class Triangle : Figure
    {

        Point p1, p2, p3;

        override public double getSquare()
        {
            return (1 / 2) * Math.Abs(
            (p1.x - p3.x) * (p2.y - p3.y)
            - (p2.x - p3.x) * (p1.y - p3.y));
        }

        override public Point getCenterOfMass()
        {
            return new Point(
                (p1.x + p2.x + p3.x) / 3,
            (p1.y + p2.y + p3.y) / 3);
        }

        override public double getPerimeter()
        {
            return (
            new Line(p1, p2).getLenght() +
            new Line(p1, p3).getLenght() +
            new Line(p2, p3).getLenght()
            );
        }

        override public String getType()
        {
            return "Triangle";
        }

        public Triangle(Point a, Point b, Point c)
        {
            p1 = a;
            p2 = b;
            p3 = c;
        }
    }


    //Класс круга
    class Circle : Figure
    {

        Point center;
        double radius;

        override public double getSquare()
        {
            return Math.PI * (radius) * (radius);
        }

        override public Point getCenterOfMass()
        {
            return center;
        }

        override public double getPerimeter()
        {
            return 2 * Math.PI * (radius);
        }

        override public String getType()
        {
            return "Circle";
        }

        public Circle(Point center1, double radius1)
        {
            if (radius1 <= 0)
            {
                throw (new System.Exception("Radius should be more than 0"));
            }
            center = center1;
            radius = radius1;
        }
    }

    //Класс трапеции
    class Trapeze : Figure
    {

        Point p1, p2, p3, p4;

        override public double getSquare()
        {
            Triangle a = new Triangle(p1, p2, p3);
            Triangle b = new Triangle(p1, p4, p3);
            return a.getSquare() + b.getSquare();
        }

        override public Point getCenterOfMass()
        {
            Line a = new Line(p2, p3);
            Line b = new Line(p1, p4);
            Line center = new Line(a.getCenter(), b.getCenter());

            double h = Math.Abs(b.p1.y - a.p1.y);
            double y = h / 3 * ((2 * b.getLenght() + a.getLenght()) / (b.getLenght() + a.getLenght()));
            Point aa = a.getCenter();
            aa.x -= 1;
            aa.y = p2.y - y;
            Point ab = a.getCenter();
            ab.x += 1;
            ab.y = p2.y - y;
            Line second = new Line(aa, ab);
            return center.cross(second);

        }

        override public double getPerimeter()
        {
            return (
           new Line(p1, p2).getLenght() +
           new Line(p4, p3).getLenght() +
           new Line(p4, p1).getLenght() +
           new Line(p2, p3).getLenght()
   );
        }

        override public String getType()
        {
            return "Trapeze";
        }

        public Trapeze(Point a, Point b, Point c, Point d)
        {
            p1 = a;
            p2 = b;
            p3 = c;
            p4 = d;
        }
    }

    //Класс Картинка - фасад. Является массивом объектов типа Figure
    class Picture
    {
        ArrayList figures = new ArrayList();

        public void push(Figure ob)
        {
            figures.Add(ob);
        }

        public void printTypes()
        {
            foreach (Figure figure in figures)
            {
                Console.WriteLine(figure.getType());
            }

        }

        public void printSquares()
        {
            foreach (Figure figure in figures)
            {
                Console.WriteLine(figure.getType() + " " + figure.getSquare());
            }

        }

        public void printCenterOfMasss()
        {
            foreach (Figure figure in figures)
            {
                Point t = figure.getCenterOfMass();
                Console.WriteLine(figure.getType() + " " + t.x +" " + t.y);
            }

        }

        public void printPerimeters()
        {
            foreach (Figure figure in figures)
            {
                Console.WriteLine(figure.getType() + " " + figure.getPerimeter());
            }

        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Picture pic = new Picture();
            Triangle a = new Triangle(new Point(1, 1), new Point(2, 1), new Point(3, -10));
            Rectangle b = new Rectangle(new Point(1, 1), new Point(1, 2), new Point(4, 2), new Point(4, 1));
            Circle c = new Circle(new Point(1, 1), 10.5);
            Trapeze d = new Trapeze(new Point(1, 1), new Point(2, 2), new Point(3, 2), new Point(4, 1));
            pic.push(a);
            pic.push(b);
            pic.push(c);
            pic.push(d);
            pic.printTypes();
            pic.printPerimeters();
            pic.printSquares();
            pic.printCenterOfMasss();
        }
    }
}